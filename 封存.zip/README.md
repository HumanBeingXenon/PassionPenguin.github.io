# PassionPenguin.github.io
PassionPenguin.github.io

Open source for Metro Wiki and ways of solving math problems
working on newing UI as well

I'am try my best to fill the proj since 2016, and I've deleted this repo for over 5 times and renew it as well, as it looks pretty and contains much more valuable content.
